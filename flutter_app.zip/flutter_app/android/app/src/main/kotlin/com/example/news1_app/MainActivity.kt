package com.example.news1_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
