import 'package:flutter/material.dart';
import 'package:news1_app/models/news_update_model.dart';
import 'package:news1_app/providers/news_update_provider.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) {
        Provider.of<NewsUpdateProvider>(context, listen: false)
            .fetchNewsUpdate();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          children: [
            Consumer<NewsUpdateProvider>(
              builder: (context, newsUpdate, child) {
                if (newsUpdate.isLoading) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                } else if (newsUpdate.newsList.isEmpty) {
                  return const Text("No news available");
                } else {
                  return buildNewsUpdate(newsUpdate.newsList.first);
                }
              },
            )
          ],
        ),
      ),
    );
  }

  Widget buildNewsUpdate(NewsUpdateModel news) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Terbaru'),
        const SizedBox(
          height: 16,
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: (news.posts?.take(5) ?? []).map(
              (item) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  margin: const EdgeInsets.only(right: 23),
                  height: 206,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage(item.thumbnail ?? ''),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Column(
                    children: [
                      Text(
                        item.title ?? '',
                        style: const TextStyle(
                          color: Colors.white,
                        ),
                      )
                    ],
                  ),
                );
              },
            ).toList(),
          ),
        ),
      ],
    );
  }
}
